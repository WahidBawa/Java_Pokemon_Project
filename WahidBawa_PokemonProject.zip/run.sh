cd ~/Documents/GitHub/Java_Pokemon_Project
exec ~/scripts/compiler PokemonArena.java PokemonArena
